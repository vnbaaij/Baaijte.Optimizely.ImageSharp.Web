define(
"dojox/atom/widget/nls/fi/FeedViewerEntry", ({
	deleteButton: "[Poista]"
})
);
