define(["build/plugins/i18n"], function (plugin) {
    return {
        start: function (mid, referenceModule, bc) {
            if (/^epi/.test(mid)) {
                return [bc.amdResources["dojo/i18n"]];
            }
            return plugin.start(mid, referenceModule, bc);
        }
    };
});
