﻿/*
This is the main layer build profile for the framwork client side files.
*/

var paths = (function () {
    var defaultPath = getCommandLineArg("sourceBasePath", true);
    return {
        sourceBasePath: defaultPath,
        toolsPath: getCommandLineArg("toolsPath") || combinePaths(defaultPath, "episerver-buildscripts"),
        shellBasePath: getCommandLineArg("shellBasePath") || defaultPath,
        cmsBasePath: getCommandLineArg("cmsBasePath") || defaultPath
    };
})();

console.log("Build path configuration:\n", paths);

function combinePaths(first, second) {
    return first.replace(/\/*$/, "") + "/" + second;
}

function getCommandLineArg(name, throwIfMissing) {
    var args = dojo.config.commandLineArgs;

    var argName = "--" + name;

    for (var p in args) {
        if (args[p] == argName) {
            return args[parseInt(p) + 1][0];
        }
    }

    if (throwIfMissing) {
        throw new Error("Missing command line parameter '" + argName + "'");
    }

    return null;
}

var dojoxModules = [
    "dojox/main",
	"dojox/layout",
    "dojox/gauges",
	"dojox/form",
    "dojox/gesture",
    "dojox/embed",
    "dojox/lang",
    "dojox/gfx",
    "dojox/charting",
    "dojox/data",
    "dojox/sql",
    "dojox/storage",
    "dojox/flash",
    "dojox/rpc",
    "dojox/atom",
    "dojox/json",
    "dojox/fx",
    "dojox/i18n",
    "dojox/color",
    "dojox/math",
	"dojox/mdnd",
	"dojox/form",
	"dojox/grid",
	"dojox/string",
	"dojox/dtl",
    "dojox/html",
    "dojox/xml",
    "dojox/date",
    "dojox/widget",
    "dojox/validate",
    "dojox/encoding",
    "dojox/socket",
    "dojox/mvc",
    "dojox/uuid"
];

var dojoxModulesExclude = ["dojox/data/s3", "dojox/storage", "dojox/rpc/OfflineRest"];

var profile = {
    basePath: "./",
    cssOptimize: true,
    internStrings: true,
    layerOptimize: "shrinksafe",
    localeList: null,
    mini: true,
    copyTests: false,
    optimize: "shrinksafe",
    stripConsole: "normal",
    selectorEngine: "acme",
    staticHasFeatures: { "config-enableLogger": getCommandLineArg("enableLogger", false) === "true" },
    transforms: { writeOptimized: [combinePaths(paths.toolsPath, "transforms/writeOptimized.js"), "write"] },
    plugins: {
        "dojo/i18n": combinePaths(paths.toolsPath, "plugins/dojo.i18n.js"),
        "epi/i18n": combinePaths(paths.toolsPath, "plugins/epi.i18n.js")
    },
    packages: [
        {
            name: "dojo",
            location: combinePaths(paths.sourceBasePath, "dojo/")
        },
        {
            name: "dijit",
            location: combinePaths(paths.sourceBasePath, "dijit/")
        },
        {
            name: "dojox",
            location: combinePaths(paths.sourceBasePath, "dojox/"),
            resourceTags: {
                ignore: function (filename, mid) {
                    if (/\/test\//.test(mid) || /\/demos\//.test(mid) || /\/doc\//.test(mid) || /Tester/.test(mid)) {
                        return true;
                    }

                    for (var i = 0; i < dojoxModulesExclude.length; i++) {
                        if (mid.indexOf(dojoxModulesExclude[i]) == 0) {
                            return true;
                        }
                    }

                    for (var i = 0; i < dojoxModules.length; i++) {
                        if (mid.indexOf(dojoxModules[i]) == 0) {
                            return false;
                        }
                    }

                    return true;
                }
            }
        }, {
            name: "epi",
            location: combinePaths(paths.shellBasePath, "epi"),
            // Release directory points to framework/dtk.
            // Write epi outside of dtk.
            destLocation: "epi/"
        }, {
            name: "epi-cms",
            location: combinePaths(paths.cmsBasePath, "epi-cms"),
            destLocation: "epi-cms/"
        }, {
            name: "dgrid",
            location: combinePaths(paths.sourceBasePath, "dgrid"),
            // Release directory points to framework/dtk.
            // Write outside of dtk.
            destLocation: "lib/dgrid/"
        }, {
            name: "put-selector",
            location: combinePaths(paths.sourceBasePath, "put-selector"),
            // Release directory points to framework/dtk.
            // Write outside of dtk.
            destLocation: "lib/put-selector/"
        }, {
            name: "xstyle",
            location: combinePaths(paths.sourceBasePath, "xstyle"),
            // Release directory points to framework/dtk.
            // Write outside of dtk.
            destLocation: "lib/xstyle/"
        }]
};
