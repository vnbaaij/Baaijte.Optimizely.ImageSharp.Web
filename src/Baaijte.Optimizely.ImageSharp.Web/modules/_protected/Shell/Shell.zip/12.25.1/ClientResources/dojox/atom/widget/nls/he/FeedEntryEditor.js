//>>built
define("dojox/atom/widget/nls/he/FeedEntryEditor",({doNew:"[חדש]",edit:"[עריכה]",save:"[שמירה]",cancel:"[ביטול]"}));