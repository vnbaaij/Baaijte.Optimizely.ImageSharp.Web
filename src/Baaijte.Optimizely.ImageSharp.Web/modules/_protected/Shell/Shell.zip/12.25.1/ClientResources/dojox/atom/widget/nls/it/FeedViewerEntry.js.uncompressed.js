define(
"dojox/atom/widget/nls/it/FeedViewerEntry", ({
	deleteButton: "[Elimina]"
})
);
