﻿/*
This is the layer configuration for the framwork client side files.
*/

var profile = {
    layers: {
        "epi/epi": {
            // Minimal requirements for bootstrapping our application.
            // Shouldn't include any ui widgets.
            include: ["epi/epi"],
            exclude: ["dojo"]
        },
        /* We have to build the layer result to a different file, otherwise the layerfile seems broken and individual request for each files are made */
        "epi/shell/widgets": {
            // Everything from shell not already included in the bootstrapper layer.
            include: ["epi/layers/epi-widgets"],
            exclude: ["dojo", "epi/epi"]
        },
        "epi-cms/widgets": {
            include: ["epi-cms/layers/cms-widgets"],
            exclude: ["dojo", "dijit/dijit", "epi/epi", "epi/layers/epi-widgets"]
        }

    }
};
