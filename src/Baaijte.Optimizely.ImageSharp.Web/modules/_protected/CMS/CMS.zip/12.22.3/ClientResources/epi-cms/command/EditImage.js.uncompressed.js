define("epi-cms/command/EditImage", [
    // dojo
    "require",
    "dojo/_base/declare",
    "dojo/on",
    "dojo/topic",
    "dojo/when",

    // epi
    "epi/dependency",
    "epi/shell/TypeDescriptorManager",
    "epi/shell/widget/dialog/Dialog",

    // EPi CMS
    "epi-cms/ApplicationSettings",
    "epi/shell/command/_Command",
    "epi/shell/command/_SelectionCommandMixin",

    // Resources
    "epi/i18n!epi/cms/nls/episerver.cms.command",
    "epi/i18n!epi/cms/nls/edit.imageeditor",
    "epi/i18n!epi/shell/nls/button"
], function (
    moduleRequire,
    // dojo
    declare,
    on,
    topic,
    when,

    // epi
    dependency,
    TypeDescriptorManager,
    Dialog,

    // EPi CMS
    ApplicationSettings,
    _Command,
    _SelectionCommandMixin,

    // Resources
    resources,
    editorResources,
    buttonResources
) {

    function isImageEditorEnabled() {
        return (ApplicationSettings.imageEditor || {}).enabled;
    }

    return declare([_Command, _SelectionCommandMixin], {
        // tags:
        //      public

        // contentDataStore: [Object] rest store
        //      Used to get content data when model is changed.
        contentDataStore: null,

        // canExecute: [readonly] Boolean
        //      Flag which indicates whether this command is able to be executed.
        canExecute: false,

        // iconClass: [readonly] String
        //      The icon class of the command to be used in visual elements.
        iconClass: "epi-iconNewWindow",

        label: resources.openineditor,

        tooltip: resources.openineditor,

        _execute: function () {
            var target = this._getTarget();
            if (!target) {
                return;
            }

            this._getContentDataStore().get(target.contentLink).then(function (contentData) {
                if (!contentData) {
                    return;
                }

                var onCallback = function (returnValue) {
                    if (returnValue) {
                        // Request context change when save or save as asset image
                        topic.publish("/epi/shell/context/request", { url: returnValue.dataset.mceSrc ? returnValue.dataset.mceSrc : contentData.previewUrl }, { forceReload: true });
                    }
                };

                var img = document.createElement("img");
                img.src = contentData.previewUrl;

                this.showImageEditorDialog(img, onCallback, onCallback);
            }.bind(this));

        },

        postscript: function () {
            this.inherited(arguments);
            this.contextService = this.contextService || dependency.resolve("epi.shell.ContextService");
            this._typeDescriptorManager = this.typeDescriptorManager || TypeDescriptorManager;
        },

        showImageEditorDialog: function (imageNode, onHide, onCallback) {
            var options = ApplicationSettings.imageEditor || {};
            if (!options.windowHeight) {
                options.windowHeight = 0;
            }
            if (!options.windowWidth) {
                options.windowWidth = 0;
            }
            if (!options.sizePresets) {
                options.sizePresets = [
                    { name: "320*240", width: 320, height: 320 },
                    { name: "640*480", width: 640, height: 480 }
                ];
            }

            moduleRequire(["epi-cms-react/components/image-editor-widget", "xstyle/css!epi-cms-react/components/image-editor-widget.css"],
                function (ImageEditorWidget) {
                    var content = new ImageEditorWidget({
                        resources: editorResources,
                        helpLink: ApplicationSettings.userGuideUrl + "#imageeditor",
                        imageSource: imageNode.src,
                        width: imageNode.width,
                        height: imageNode.height,
                        filename: imageNode.src.replace(/^.*[\\\/]/, "").split(",,")[0],
                        presetOptions: options.sizePresets,
                        readOnly: !isImageEditorEnabled(),
                        onChange: function (value) {
                            if (value) {
                                imageNode.src = value;
                                imageNode.dataset.mceSrc = value;
                            }
                        }
                    });

                    var dialog = new Dialog({
                        dialogClass: "epi-dialog--wide",
                        defaultActionsVisible: true,
                        confirmActionText: buttonResources.save,
                        content: content,
                        title: editorResources.title,
                        focusActionsOnLoad: true,
                        validate: function () {
                            content.onDialogSubmit();
                            return false;
                        }
                    });
                    on.once(dialog, "execute", function (value) {
                        onCallback(imageNode, value);
                    });
                    on.once(dialog, "cancel", function () {
                        onHide();
                    });
                    dialog.own(content.on("rendercompleted", function () {
                        dialog.resize();
                    }));

                    if (options.windowWidth) {
                        dialog.containerNode.style.width = options.windowWidth + "px";
                    }

                    if (options.windowHeight) {
                        dialog.containerNode.style.height = options.windowHeight + "px";
                    }

                    dialog.show();
                }.bind(this));
        },

        _onModelChange: function () {
            // summary:
            //      Updates canExecute after the model has been updated.
            // tags:
            //      protected

            if (!isImageEditorEnabled()) {
                if (this.get("isAvailable")) {
                    this.set("isAvailable", false);
                }
                this.set("canExecute", false);
                return;
            }

            var target = this._getTarget(),
                canExecute = target &&  // Ensure there is something selected.
                    this._typeDescriptorManager.isBaseTypeIdentifier(target.typeIdentifier, "episerver.core.icontentimage");  // Check that it is image content.

            if (canExecute) {
                var supportedEditExtensions = (ApplicationSettings.imageEditor || {}).supportedEditExtensions;
                if (!supportedEditExtensions) {
                    canExecute = false;
                } else {
                    canExecute = supportedEditExtensions.some(function (ext) {
                        return target.name.toLowerCase().endsWith(ext);
                    });
                }
            }

            this.set("isAvailable", !!canExecute);
            this.set("canExecute", !!canExecute);

        },

        _getTarget: function () {
            // summary:
            //      Returns the target for the file operation from the current selection.
            // tags:
            //      protected

            return this._getSingleSelectionData();
        },

        _getContentDataStore: function () {
            // summary:
            //      Gets the content data store from store registry if it's not already cached

            if (!this.contentDataStore) {
                var registry = dependency.resolve("epi.storeregistry");
                this.contentDataStore = registry.get("epi.cms.contentdata");
            }
            return this.contentDataStore;
        }
    });
});
